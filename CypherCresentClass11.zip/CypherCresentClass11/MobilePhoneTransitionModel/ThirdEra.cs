﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobilePhoneTransitionModel
{
    public class ThirdEra : SecondEra
    {
        // Constructors

        // Methods
        public virtual void Email()
        {

        }
        public virtual void Games()
        {

        }
        public virtual void Messaging()
        {

        }
        // Properties

        //public int Call { get; set; }
        //public string TextMessage { get; set; }
    }
}
