﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobilePhoneTransitionModel
{
    public class SecondEra : FirstEra
    {
        // Constructors

        // Methods
        public virtual void Camera()
        {

        }
        public virtual void Video()
        {

        }
        public virtual void MMS()
        {

        }
        // Properties

        //public int Call { get; set; }
        //public string TextMessage { get; set; }
    }
}
