﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobilePhoneTransitionModel
{
    public class FirstEra : Phone
    {
        // Constructors

        // Methods
        public virtual void Call()
        { 

        }
        public virtual void TextMessage()
        {

        }
        // Properties

        //public int Call { get; set; }
        //public string TextMessage { get; set; }
    }
}
