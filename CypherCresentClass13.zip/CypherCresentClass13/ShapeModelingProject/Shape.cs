﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeModelingProject
{
    public abstract class Shape
    {
        // Constructors

        // Methods
        public abstract double CalculateSurfaceArea();

        // Properties
        public double Width { get; set; }
        public double Height { get; set; }
    }
}
