﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeModelingProject
{
    public class Circle : Shape
    {
        // Constructors
        public Circle(double height, double width)
        {
            height = base.Height;
            width = base.Width;

            double radius;
            radius = height + width;
            Radius = radius;
        }

        // Methods
        public override double CalculateSurfaceArea()
        {
            double AreaOFCircle;
            AreaOFCircle = Math.PI * Math.Pow((this.Radius), 2);
            Console.WriteLine(Radius);
            return AreaOFCircle;
        }

        // Properties
        public double Radius { get; set; }
    }
}
/*
 using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeModelingProject
{
    public class Circle : Shape
    {
        // Constructors
        public Circle(double height, double width)
        {
            height = base.Height;
            width = base.Width;

            //double radius;
            //radius = height + width;
            //Radius = radius;
        }

        // Methods
        public override double CalculateSurfaceArea()
        {
            double radius;
            radius = this.height + this.width;
            double AreaOFCircle;
            AreaOFCircle = Math.PI * Math.Pow((radius), 2);
            Console.WriteLine("EWEw" + Radius);
            return AreaOFCircle;
        }

        // Properties
        private int myVar;

        public int Radius
        {
            get { return myVar; }
            set { myVar = radius; }
        }

        //public double Radius { get; set; }
    }
}
 */
