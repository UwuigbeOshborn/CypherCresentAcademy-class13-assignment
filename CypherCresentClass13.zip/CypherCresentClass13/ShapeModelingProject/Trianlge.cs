﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeModelingProject
{
    internal class Trianlge : Shape
    {
        // Constructors

        // Methods
        public override double CalculateSurfaceArea()
        {
            double AreaOFTriangle;
            AreaOFTriangle = (Width * Height)/2;
            return AreaOFTriangle;
        }
        // Properties
    }
}
