﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeModelingProject
{
    internal class Rectangle : Shape
    {
        // Constructors

        // Methods
        public override double CalculateSurfaceArea()
        {
            double AreaOFRectangle;
            AreaOFRectangle = Width * Height;
            return AreaOFRectangle;
        }
        // Properties
    }
}
