﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolModelingProject
{
    internal class Teacher : People
    {
        // Constructors

        // Methods

        // Properties
        public int AssignedCourse { get; set; }
        public int AssignedClassRoom { get; set; }
    }
}
