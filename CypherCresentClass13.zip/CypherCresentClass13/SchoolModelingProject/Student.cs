﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolModelingProject
{
    internal class Student : People
    {
        // Constructors

        // Methods

        // Properties
        public int IdentificationNumber { get; set; }
        public string ClassRoomID { get; set; }
    }
}