﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolModelingProject
{
    internal class ClassRoom : School
    {
        // Constructors

        // Methods

        // Properties
        public Char ClassRoomID { get; set; }
    }
}
