using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProject
{
    public class Individual : Customer
    {
    	// Constructors
    	
    	// Methods
    	
    	// Properties
    	public bool IndividualOwnershipStatus { get; set; }
    }
}
