using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProject
{
    public class DepositAccount : Account
    {
    	// Constructors
    	
    	// Methods
    	public override void DepositMoney()
        {
            base.DepositMoney();
            // Issue  Deposit Receipt
        }
        public override void WithdrawMoney()
        {
            base.WithdrawMoney();
            // Issue  Withdrawal Receipt
        }
        public override void CalculateInterest()
        {
            //Account Balance = new Account.Balance();
            this.Balance = Balance;

            if (Balance > 1000)
	        {
	        	base.CalculateInterest();
	        }
	        else
	        {
                double Interest;

                Interest = 0;
	        	// because InterestRate is zero
	        }
        }
    	
    	// Properties
    	
    }
}
