using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProject
{
    public class LoanAccount : Account
    {
    	// Constructors
    	
    	// Methods
    	public override void DepositMoney()
        {
            base.DepositMoney();
            // Issue  Loan Certificate
        }
        
        public override void CalculateInterest()
        {
	        Individual OwnershipStatus1 = new Individual();
	        Company OwnershipStatus2 = new Company();
            this.NumberOfMonths = NumberOfMonths;

            if (OwnershipStatus1.IndividualOwnershipStatus == true)
	        {
                if (NumberOfMonths < 3)
                {
                    double Interest;

                    Interest = 0;
                    // because InterestRate is zero
                }
                else
                {
                    base.CalculateInterest();
                }
            }
	        else if (OwnershipStatus2.CompanyOwnershipStatus == true)
	        {
                if (NumberOfMonths < 2)
                {
                    double Interest;

                    Interest = 0;
                    // because InterestRate is zero
                }
                else
                {
                    base.CalculateInterest();
                }
            }
	        else
	        {
	            base.CalculateInterest();
	        }
        }
    	
    	// Properties
        
    }
}
