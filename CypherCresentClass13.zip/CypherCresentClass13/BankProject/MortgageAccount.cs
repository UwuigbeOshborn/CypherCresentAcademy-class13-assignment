using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProject
{
    public class MortgageAccount : Account
    {
    	// Constructors
    	
    	// Method
    	public override void DepositMoney()
        {
            base.DepositMoney();
            // Issue  Mortgage Certificate
        }
        public override void CalculateInterest()
        {
	        Individual OwnershipStatus1 = new Individual();
	        Company OwnershipStatus2 = new Company();
			//Account NumberOfMonth = new Account.NumberOfMonths();
			//Account NumberOfMonth = new Account();
			this.NumberOfMonths = NumberOfMonths;

			if (OwnershipStatus1.IndividualOwnershipStatus == true)
	        {
	        	if (NumberOfMonths <= 12)
	        	{
	        		double Interest;
        	
        			Interest = NumberOfMonths * (InterestRate/2);
	        	}
	        	else
	        	{
	        		base.CalculateInterest();
	        	}
	        }
	        else if (OwnershipStatus2.CompanyOwnershipStatus == true)
	        {
	        	if (NumberOfMonths <= 6)
	        	{
					double Interest;

					Interest = 0;
	        		// because InterestRate is zero
	        	}
	        	else
	        	{
	        		base.CalculateInterest();
	        	}
	        }
	        else
	        {
	            base.CalculateInterest();
	        }
        }
    	
    	// Properties
        
    }
}
