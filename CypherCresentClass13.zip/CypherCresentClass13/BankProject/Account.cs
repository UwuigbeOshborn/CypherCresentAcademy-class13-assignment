using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProject
{
    public abstract class Account : Bank, IDeposit, IWithdraw
    {
        // Constructors
        
        // Methods
        public virtual void DepositMoney()
        {
            // DepositMoney;
        }
        public virtual void WithdrawMoney()
        {
            // WithdrawMoney;
        }
		public virtual void CalculateInterest()
        {
        	double Interest;
        	
        	Interest = NumberOfMonths * InterestRate;
        }
        
        // Properties
        public Customer Customer { get; set; }

        public Decimal Balance { get; set; }

        public float InterestRate { get; set; }
        
        public int NumberOfMonths { get; set; }
    }
}
