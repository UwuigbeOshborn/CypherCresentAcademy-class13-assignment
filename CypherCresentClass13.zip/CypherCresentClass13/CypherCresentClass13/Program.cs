﻿using ShapeModelingProject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass13
{
    public class Program
    {
        static void Main(string[] args)
        {
            double createcircle = new Circle(4, 3).CalculateSurfaceArea();
            Console.WriteLine(createcircle);
        }
    }
}
