﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HumanModelingProject
{
    public class Worker : Human
    {
        // Constructors

        // Methods
        public void CalculateHourlyWage()
        {
            decimal HourlyWage;
            HourlyWage = Wage / HoursWorked;
        }
        // Properties
        public int Wage { get; set; }
        public int HoursWorked { get; set; }
    }
}
