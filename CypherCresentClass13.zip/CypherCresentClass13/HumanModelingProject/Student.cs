﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HumanModelingProject
{
    public class Student : Human
    {
        // Constructors

        // Methods

        // Properties
        public int Mark { get; set; }
    }
}
